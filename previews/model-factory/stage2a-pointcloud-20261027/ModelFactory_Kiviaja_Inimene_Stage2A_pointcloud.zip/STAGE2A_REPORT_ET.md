# ModelFactory Lab - Stage 2A: punktipilve taastamise katse
27.10.2026

## Teostatud
Vigaste neljavaadetega seotud failide põhjal valmis 166310-punktiline binaarne PLY.
- Kaamera eest: ühe figuuri siluetist tuletatud X/Z koordinaadid, piltidelt RGB.
- Kaamera tagant: ligikaudu joondatud ning osalt nähtavad seljakülje detailid.
- Keha sügavus Y teljel: inimkeha üldproportsioonid, mitte tegelik mõõdetud multiview.
- Kaks pseudokülgvaadet: väga madal kaal; mõjutavad arvutatud sügavust ainult piiratud umbes 1.8%, sest neis on kaamera suund vale.
- Uuest punktipilvest projitseeriti 4 külge ja 3/4 vaade.
- PLY kandeväljad: x/y/z, red/green/blue, source, confidence. source=0 front, 1 back, 2 oletatud. Confidence 235/175/82/65.

## Valideerimisnumbrid
- Front mask: 260055 pikslit
- Back mask: 225495 pikslit
- Joondatud FRONT/BACK siluettide IoU: 0.6729
- Back kattuvus FRONT silueti suhtes: 0.8058
- Eeldatud pikkus: 1.78 m (mitte mudelist mõõdetud)
- Erinevad kaamerad ei esita võrdse geomeetrilise usaldusväärsusega infot.

## Olulised piirangud
See PLY EI OLE täielik mõõdetud 3D-inimene; see on 2D-siluetist paisutatud esmane sügavuse hüpotees.
3D nurkvaate vaadates on näha külgsuunalist venimist, õhukesi pindu, pildi järgi toimivat fronti ja ebajärjepidevaid tekstuure.
Pildilt ei saa järeldada keha tegelikku sügavust, rindkere ja õlgade kuju või juuste-käte üksikasju.
Järgmiseks peaks kontrollima 3D sügavuspriorit, liigendite topoloogiat ning rohkem kvaliteetseid päris külgvaateid, kuid ilma kasutaja nõusolekuta ei alusta Stage 2B.

## Sisend
Originaalid ModelFactory-Lab projektis: `stage1_tpose_fourviews_20261027`.
Eest: `Tpose_front.png`, tagant: `Tpose_back.png`, pseudo-küljed: `Tpose_left_repair_v2.png`, `Tpose_right_repair_v2.png`.

## Staatus
STAGE 2A: katseliselt valminud.
STAGE 2B: ei alustatud.
Mesh, UV, PBR, rig, animatsioonid: ei alustatud.

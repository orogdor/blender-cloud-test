"""
ModelFactory Stage 2A, demonstrator. FRONT silhouette is authoritative.
BACK supplies partial back texture/secondary silhouette validation.
AI-generated pseudo-sides are NOT interpreted as 90-degree camera projections.
Adds anatomically plausible thickness, no 3D facts recovered where unseen.
Output: colored PLY with source+confidence and diagnostic turnaround renders.
"""
from PIL import Image,ImageDraw,ImageFont
from pathlib import Path
from scipy import ndimage as ndi
import numpy as np, json, struct, hashlib, math
ROOT=Path(__file__).resolve().parent
SRC=ROOT.parent/"stage1_tpose_fourviews_20261027"
W,H=832,1216
def load(name):
 return np.array(Image.open(SRC/name).convert("RGB"))
front=load("Tpose_front.png");back=load("Tpose_back.png")
left=load("Tpose_left_repair_v2.png");right=load("Tpose_right_repair_v2.png")
def silhouette(a):
 # Full-image background in these generations is mostly uniform per scan line.
 bg=np.median(np.concatenate((a[:,5:20,:],a[:,-20:-5,:]),axis=1),axis=1)
 delta=np.max(np.abs(a.astype(np.float32)-bg[:,None,:]),axis=2)
 rough=ndi.binary_closing(delta>25,iterations=3)
 labels,count=ndi.label(rough)
 hist=np.bincount(labels.ravel());hist[0]=0
 mask=labels==np.argmax(hist)
 mask=ndi.binary_fill_holes(mask)
 return mask
F=silhouette(front);B=silhouette(back);L=silhouette(left);R=silhouette(right)
for key,mask in (("front",F),("back",B),("left",L),("right",R)):
 Image.fromarray((mask*255).astype(np.uint8)).save(ROOT/(key+"_silhouette.png"))
# Human portrait is exactly derived from front image bounding box at 1.78m height.
fy,fx=np.where(F)
xmin,xmax=int(fx.min()),int(fx.max())
top,bottom=int(fy.min()),int(fy.max())
center_x=(xmin+xmax)/2
height_m=1.78
pixels_per_m=(bottom-top)/height_m
rows=np.arange(H)
backy,backx=np.where(B)
backtop,backbot=int(backy.min()),int(backy.max())
back_cx=(int(backx.min())+int(backx.max()))/2
scale_back_x=(backx.max()-backx.min())/float(xmax-xmin)
scale_back_y=(backbot-backtop)/float(bottom-top)
# Silhouette confidence: front authoritative; partial posterior may disagree.
back_mapped_x=np.clip(np.rint(back_cx-(np.arange(W)-center_x)*scale_back_x).astype(int),0,W-1)
back_mapped_y=np.clip(np.rint(backtop+(np.arange(H)-top)*scale_back_y).astype(int),0,H-1)
B_aligned=B[np.ix_(back_mapped_y,back_mapped_x)]
Image.fromarray((B_aligned*255).astype(np.uint8)).save(ROOT/"back_aligned_silhouette.png")
overlap=F&B_aligned
back_agreement=float(overlap.sum()/max(1,F.sum()))
back_iou=float(overlap.sum()/max(1,(F|B_aligned).sum()))
# distance to outer image silhouette: a smooth artificial rounded-depth prior.
dt=ndi.distance_transform_edt(F)
v,u=np.mgrid[0:H:2,0:W:2]
valid=F[::2,::2]
yy=v[valid].astype(np.int32);xx=u[valid].astype(np.int32)
dist=dt[yy,xx]
xp=(xx-center_x)/pixels_per_m
z=(bottom-yy)/pixels_per_m
# Distinguish horizontal arms from torso/head by pixel plane.
abs_dx=np.abs(xx-center_x)
is_head=(yy<260) & (abs_dx<125)
is_arm=(yy>=240)&(yy<=445)&(abs_dx>=130)
is_lower_leg=(yy>=865)
is_torso=(yy>=260)&(yy<570)&(~is_arm)
is_garment=(yy>=570)&(yy<865)
depth=np.full(len(xx),0.15,dtype=np.float32)
depth[is_head]=0.116
depth[is_arm]=0.062
depth[is_torso]=0.176
depth[is_garment]=0.175
depth[is_lower_leg]=0.085
# Moccasins project towards camera / toe depth.
depth[yy>1095]=0.127
# Shoulder fur/fabric stays slightly thicker.
depth[(yy>=240)&(yy<480)&(abs_dx<145)]=0.184
# Adapt torso thickness to user idea of averaging weak pseudo side silhouette
# but restrict the influence to at most +/- 5 percent: sides are NOT geometric truth.
def width_at(mask,y0,y1,x0=260,x1=590):
 band=mask[y0:y1,x0:x1]
 return float(np.mean(np.sum(band,axis=1))) if len(band) else 0.0
wF=width_at(F,505,655)
wL=width_at(L,505,655)
wR=width_at(R,505,655)
weak_observed=0.5*(wL+wR)/max(1,wF)
side_adjust=float(np.clip(1+0.1*(weak_observed-1),0.95,1.05))
depth*=side_adjust
radius_cap=np.where(is_arm,16.0,np.where(is_head,25.0,34.0))
# Rounded extrusion: at silhouette edges profile closes, at core gets full guessed thickness.
rounding=np.sqrt(np.minimum(1.0,np.maximum(0.002,dist/radius_cap)))
half_depth=np.maximum(0.006,depth*rounding)
# Two fitted shell surfaces per foreground grid sample.
uvB=back_mapped_x[xx]
vB=back_mapped_y[yy]
rgbF=front[yy,xx].astype(np.uint8)
rgbB=back[vB,uvB].astype(np.uint8)
back_seen=B[vB,uvB]
# When back is missing, use plausible muted extrapolation of foreground colors.
backup=np.clip(rgbF.astype(np.float32)*0.77+np.array([32,24,17]),0,255).astype(np.uint8)
rgbB=np.where(back_seen[:,None],rgbB,backup)
# Human model coordinate X left-right, Y back-positive, Z up. Front observer at Y-negative.
surface1=np.column_stack((xp,-half_depth,z)).astype("<f4")
surface2=np.column_stack((xp,half_depth,z)).astype("<f4")
conf1=np.full(len(xx),235,np.uint8)
conf2=np.where(back_seen,175,82).astype(np.uint8)
src1=np.zeros(len(xx),dtype=np.uint8) # FRONT measured silhouette
src2=np.where(back_seen,1,2).astype(np.uint8) # BACK supported or inferred
# Rim points add a thin side boundary to connect front/back.
edge=F&~ndi.binary_erosion(F,iterations=2)
ey,ex=np.where(edge)
choose=(np.arange(len(ey))%2)==0
ey=ey[choose];ex=ex[choose]
# prevent enormous boundary oversampling; 7 bridging points per pixel of contour
rx=(ex-center_x)/pixels_per_m
rz=(bottom-ey)/pixels_per_m
rdepth=np.maximum(0.008,np.where((ey>=240)&(ey<445)&(np.abs(ex-center_x)>130),0.035,0.06))*side_adjust
rrgb=front[ey,ex]
rimpts=[];rimrgb=[]
for t in np.linspace(-0.9,0.9,9):
 rimpts.append(np.column_stack((rx,rdepth*t,rz)).astype("<f4"))
 rimrgb.append(np.clip(rrgb.astype(np.float32)*(0.95-0.17*abs(t)),0,255).astype("u1"))
P=np.concatenate((surface1,surface2,*rimpts),axis=0)
RGB=np.concatenate((rgbF,rgbB,*rimrgb),axis=0)
SRC_CODE=np.concatenate((src1,src2,np.full(9*len(ex),2,dtype="u1")))
CONF=np.concatenate((conf1,conf2,np.full(9*len(ex),65,dtype="u1")))
assert len(P)==len(RGB)==len(SRC_CODE)==len(CONF)
assert np.all(np.isfinite(P))
cloud=np.empty(len(P),dtype=[("x","<f4"),("y","<f4"),("z","<f4"),
 ("red","u1"),("green","u1"),("blue","u1"),("source","u1"),("confidence","u1")])
for i,k in enumerate(("x","y","z")):cloud[k]=P[:,i]
for i,k in enumerate(("red","green","blue")):cloud[k]=RGB[:,i]
cloud["source"]=SRC_CODE
cloud["confidence"]=CONF
ply=ROOT/"kiviaja_mees_2A_weighted_raw_points.ply"
with ply.open("wb") as fp:
 fp.write(("ply\nformat binary_little_endian 1.0\n"
 "comment POINT CLOUD only, no topology / rig / real measured 3D\n"
 "comment reconstructed from AI images, Y depth anatomy prior\n"
 "comment source: 0 front, 1 aligned back, 2 inferred\n"
 "element vertex "+str(len(P))+"\n"
 "property float x\nproperty float y\nproperty float z\n"
 "property uchar red\nproperty uchar green\nproperty uchar blue\n"
 "property uchar source\nproperty uchar confidence\nend_header\n").encode("ascii"))
 cloud.tofile(fp)
# Orthographic re-render of the generated point cloud; sampled splats.
# view basis = displayX and approximate depth sorting index.
def render(which,w=832,h=1216):
 if which=="front":hs=P[:,0];ds=-P[:,1]
 elif which=="back":hs=-P[:,0];ds=P[:,1]
 elif which=="left":hs=P[:,1];ds=-P[:,0]
 elif which=="right":hs=-P[:,1];ds=P[:,0]
 elif which=="angle":
  a=math.radians(37)
  hs=P[:,0]*math.cos(a)+P[:,1]*math.sin(a)
  ds=-P[:,0]*math.sin(a)+P[:,1]*math.cos(a)
 else:raise ValueError(which)
 zz=P[:,2].copy()
 if which=="angle":
  zz=zz-0.17*ds
 # same 1.78m calibrated physical-height pixels in all views.
 ux=np.rint(w/2+hs*pixels_per_m*.86).astype(int)
 vy=np.rint(h-40-zz*pixels_per_m*.96).astype(int)
 ok=(ux>=0)&(ux<w)&(vy>=0)&(vy<h)
 indices=np.flatnonzero(ok)
 indices=indices[np.argsort(ds[ok])]
 image=Image.new("RGB",(w,h),(213,215,214))
 draw=ImageDraw.Draw(image)
 for n in indices:
  xx1=int(ux[n]);yy1=int(vy[n])
  col=tuple(map(int,RGB[n]))
  draw.rectangle((xx1-1,yy1-1,xx1+1,yy1+1),fill=col)
 return image
labels=("front","left","back","right","angle")
for view in labels:
 render(view).save(ROOT/("cloud_projection_"+view+".png"))
# Projected center silhouette checks in pixel image domain
# -> direct front visual is precise at source; back partly inconsistent by design.
# Compact 4-view comparison previews.
panel_w,panel_h=620,930
sheet=Image.new("RGB",(panel_w*4,panel_h+75),(225,227,226))
draw=ImageDraw.Draw(sheet)
try:font=ImageFont.truetype("C:/Windows/Fonts/segoeuib.ttf",29)
except:font=ImageFont.load_default()
for i,vname in enumerate(("front","left","back","right")):
 img=Image.open(ROOT/("cloud_projection_"+vname+".png")).convert("RGB")
 img=img.resize((panel_w,panel_h),Image.Resampling.LANCZOS)
 sheet.paste(img,(i*panel_w,75))
 draw.rectangle((i*panel_w,0,(i+1)*panel_w,75),fill=(36,42,44))
 draw.text((i*panel_w+18,16),vname.upper()+"  |  reconstructed",font=font,fill="white")
out=ROOT/"POINTCLOUD_2A_FOUR_SIDES_DRAFT.jpg"
sheet.save(out,quality=89,optimize=True)
angle=Image.open(ROOT/"cloud_projection_angle.png")
angle.save(ROOT/"POINTCLOUD_2A_ANGLE_PREVIEW.jpg",quality=91,optimize=True)
info={
 "stage":"2A only","status":"GENERATED - requires visual evaluation","user_approved":False,
 "points":int(len(P)),"front_surface_points":int(len(surface1)),
 "back_surface_points":int(len(surface2)),"inferred_edge_points":int(len(ex)*9),
 "source_front":str(SRC/"Tpose_front.png"),"source_back":str(SRC/"Tpose_back.png"),
 "pseudo_sides":["Tpose_left_repair_v2.png","Tpose_right_repair_v2.png"],
 "frontend_height_m_assumed":height_m,"pixels_per_meter":pixels_per_m,
 "front_bbox_pixels":[xmin,top,xmax,bottom],
 "front_mask_pixels":int(F.sum()),"back_mask_pixels":int(B.sum()),
 "front_back_mask_iou_after_alignment":round(back_iou,4),
 "front_back_supported_fraction_of_front":round(back_agreement,4),
 "weak_side_torso_width_proxy_ratio":round(weak_observed,3),
 "side_depth_adjustment_clamped":round(side_adjust,4),
 "depth_priors":{"head_radius_m":.116,"torso_halfdepth_m":.176,
                 "arm_radius_m":.062,"lower_leg_radius_m":.085},
 "geometric_accuracy":"front silhouette exact in grid samples; back partial color; depth inferred",
 "not_genuine_multiview_reconstruction":True,"no_mesh":True,"stage_2B_started":False,
 "pointcloud_file":ply.name,
 "ply_sha256":hashlib.sha256(ply.read_bytes()).hexdigest(),
 "preview":out.name}
(ROOT/"pointcloud_2A_manifest.json").write_text(json.dumps(info,indent=2,ensure_ascii=False),encoding="utf8")
print("SUCCESS_2A",json.dumps(info,ensure_ascii=False),flush=True)

# ModelFactory Lab ā€” Kiviaja inimene, Stage 2B (27.10.2026)

## Mis sai pĆ¤riselt tehtud
Sinu Windowsi arvutis tĆ¶Ć¶tas kohalik Python 3.13/ComfyUI portable interpreter ning 2A alg-Punktipilv oli olemas. Stage 2B prooviti kolm jĆ¤rjestikust paranduskorda; algseid faile ei kirjutatud Ć¼le.

- 2B v1: 166310 punkti sĆ¤ilisid, jagati 10 keha-/rĆµivapiirkonnaks; Y-sĆ¼gavust muudeti kehaosa prioride jĆ¤rgi. Eest- ja tagantvaade sĆ¤ilisid, kuid kĆ¼lgedel olid tĆ¼himikud.
- 2B v2: 347480 punkti, sealhulgas 181170 lisatud oletatud kĆ¼lgpinna punkti. KĆ¼ljetĆ¼himikud vĆ¤henesid, kuid mudel meenutas liiga kandilist vĆ¤ljapressitud siluetti.
- 2B v3 (soovitatav jĆ¤rgmise katse alus): 197610 punkti Ć¼mardatud anatoomiliste ristlĆµigetega: pea, kael, rindkere, pikk tuunika, kaks jalga, kaks T-poosis kĆ¤tt ja nahast vĆ¤liskiht. KĆµik punktid on 3D XYZ ja RGB-ga. Kuna need pildid ei ole tegelikud ortograafilised nelivaated, on sĆ¼gavus ja kĆµrvade, nĆ¤o ning rĆµivaste ruumiline kuju *oletatud*, mitte fotogrammeetriliselt mĆµĆµdetud.

## Visuaalne kvaliteedikontroll
- FRONT: vĆ¤limus ja T-poos on Ć¼ldiselt Ć¤ratuntavad.
- BACK: tagantvaate vĆ¤rvid pĆ¤rinevad osaliselt tagantvaate alusfotost, aga nende ruumiline suhe pole Ć¼heselt tĆµestatud.
- LEFT/RIGHT: nĆ¼Ć¼d nĆ¤itavad loodud punktipilve reaalseid 90Ā° suunast tehtud projektsioone; need on siiski hinnangulise geomeetriaga ning ei kattu vigaste originaalsete kĆ¼lgvaatega.
- 3/4: inimese ja riietuse maht on paremini nĆ¤htav kui 2A puhul, kuid vorm on endiselt geomeetriliselt ja tekstuuriliselt ebatĆ¤pne. Ć•la- ja kĆ¤eĆ¼hendused, jalatsi detailid, nĆ¤o kuju ja rĆµivaservad vajavad parandamist.
- See EI ole Lord of the Rings Online tasemega 3D-inimene. PLY EI ole valmis korralik quad-mesh, GLB ega animeeritav tegelane.

## Failid
- `Kiviaja_mees_stage2B_v3_rounded_anatomy.ply`: punktipilv (binaarne PLY).
- `Stage2B_v3_FOUR_VIEWS.jpg`: nelja kaamera uus 3D-kontroll, mitte uued AI-pildid.
- `Stage2B_v3_ANGLE.jpg`: punktipilve 3/4 projektsioon.
- `Stage2B_v3_manifest.json`: pĆ¤ritolu, punktide arv ja piirangud.
- `anatomy_round_cross_sections_v3.py`: lokaalne rekonstruktsiooniskript.
- `STAGE2B_RAPORT_ET.md`: kĆ¤esolev aruanne.

## JĆ¤rgmine samm
Stage 2B katseline vĆ¤ljastus on valmis, kuid lĆµppkvaliteet ei ole heaks kiidetud. Stage 2C (iteratiivne sobitamine, tegeliku kĆ¼lginfo vĆµi anatoomilise mudeli jĆ¤rgi tĆ¤psustamine) ja mesh'i tegemine on blokeeritud kuni kasutaja sĆµnaselge loani.

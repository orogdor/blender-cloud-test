"""Stage2B v3: rounded anatomical cross-section hypothesis from failed AI multiview.
Body prior only, point cloud, no surface topology or rig. No cloud models/plugins.
"""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import math,json,hashlib
import numpy as np
ROOT=Path(__file__).resolve().parent
SRC=ROOT.parent/"stage2A_weighted_pointcloud_20261027"
AI=ROOT.parent/"stage1_tpose_fourviews_20261027"
F=np.asarray(Image.open(AI/"Tpose_front.png").convert("RGB"))
B=np.asarray(Image.open(AI/"Tpose_back.png").convert("RGB"))
mask=np.asarray(Image.open(SRC/"front_silhouette.png").convert("L"))>127
W,H=832,1216; x0=416;ybottom=1164;pix=(1164-87)/1.78
# 3D points, colors, confidence, source image attribution and body-part region
P=[];C=[];T=[];K=[]
def rgb_sample(x,z,back=False):
 xpix=int(np.clip(round(416+x*pix),0,831))
 ypix=int(np.clip(round(1164-z*pix),0,1215))
 if back:
  # Original 2A mapping: back is mirrored and slightly vertically rescaled
  yy=int(np.clip(round(123+(ypix-87)*1009/1077),0,1215))
  xx=int(np.clip(round(415-(xpix-416)*749/812),0,831))
  color=B[yy,xx]
  if np.max(np.abs(color.astype(float)-np.array([175,176,178])))<31:
   return np.clip(np.asarray(rgb_sample(x,z,False),dtype=float)*.75+[32,27,20],0,255)
  return color.astype(float)
 if not mask[ypix,xpix]:
  valid=np.flatnonzero(mask[ypix])
  if len(valid):xpix=int(valid[np.argmin(np.abs(valid-xpix))])
 return F[ypix,xpix].astype(float)
def add(x,y,z,reg):
 if not(np.isfinite(x) and np.isfinite(y) and np.isfinite(z)):return
 f=np.clip(rgb_sample(x,z,False),0,255)
 b=np.clip(rgb_sample(x,z,True),0,255)
 # negative Y = front. Strongest front/back color fidelity at visible main faces.
 blend=np.clip((y+.020)/.09+.5,0,1)
 blend=blend*blend*(3-2*blend)
 if y < -.06: blend=0.
 if y > .06:blend=1.
 color=np.uint8(np.clip(f*(1-blend)+b*blend,0,255))
 src=0 if y<-.07 else (1 if y>.07 else 2)
 conf=208 if src==0 else (145 if src==1 else 60)
 P.append((x,y,z));C.append(tuple(color));T.append((src,conf));K.append(reg)
def ring(z,cx,rx,ry,reg,count=224,cy=0):
 for j in range(count):
  a=2*math.pi*j/count
  x=cx+rx*math.cos(a);y=cy+ry*math.sin(a)
  add(x,y,z,reg)
def row_bounds(yy,domain=None):
 pixcol=np.flatnonzero(mask[yy])
 if domain is not None:pixcol=pixcol[(pixcol>=domain[0])&(pixcol<=domain[1])]
 if len(pixcol)<4:return None
 return float(pixcol.min()),float(pixcol.max())
# Head/hair: each 2px height slice follows FRONT width; profile is rounded rather than slab.
for yy in range(87,262,2):
 b=row_bounds(yy)
 if not b:continue
 z=(ybottom-yy)/pix
 cx=((b[0]+b[1])*.5-x0)/pix
 rx=max(.025,(b[1]-b[0])/(2*pix))
 # haircut crown slightly shallower, jaw/face toward base of head.
 ry=min(.145,max(.038,rx*1.07))
 if yy<110:ry*=.75
 ring(z,cx,rx,ry,0,256,cy=-.002)
# Narrow neck transitional rings (connect head & torso).
for yy in range(260,300,2):
 z=(ybottom-yy)/pix
 t=(yy-260)/40
 ring(z,0,.10+t*.07,.088+t*.070,1,192)
# Torso / fur shoulders; upper arms added separately as oriented cylinders.
for yy in range(290,585,2):
 z=(ybottom-yy)/pix
 b=row_bounds(yy,(240,592))
 if not b:continue
 # torso max width from observed mask, capped where sleeves dominate.
 cx=((b[0]+b[1])/2-x0)/pix
 rx=max(.12,min(.245,(b[1]-b[0])/(2*pix)))
 ry=np.interp(z,[.956,1.12,1.32,1.44],[.155,.178,.193,.206])
 if yy<328:rx=max(rx,.205)
 ring(z,cx,rx,float(ry),2,264)
# Long tunic / apron; width remains measured from source silhouettes.
for yy in range(573,867,2):
 z=(ybottom-yy)/pix
 b=row_bounds(yy,(230,620))
 if not b:continue
 cx=((b[0]+b[1])/2-x0)/pix
 rx=max(.13,min(.31,(b[1]-b[0])/(2*pix)))
 ry=.179+(.029 if z>.78 else 0)+(.012 if z<.59 else 0)
 ring(z,cx,rx,ry,5,270,cy=.012)
# Independent trousers, bare skin and moccasins, each as round tapered cylinders.
for side in (-1,1):
 cx=side*.122
 for yy in range(860,1164,2):
  z=(ybottom-yy)/pix
  b=row_bounds(yy,(0,414) if side<0 else (418,831))
  if b is None:continue
  bx=((b[0]+b[1])/2-x0)/pix
  rx=max(.036,min(.103,(b[1]-b[0])/(2*pix)))
  if z>.37:r=.10;reg=6
  elif z>.12:r=.086;reg=7
  else:r=.128;reg=8
  ring(z,bx,rx,r,reg,174,cy=-.026 if reg==8 else 0)
# Two arms along X in T pose. Z is estimated from observed arm band, not rigid 1.44m.
for side in (-1,1):
 for xi in np.arange(.188,.681,.004):
  x=side*float(xi)
  t=np.clip((xi-.18)/.5,0,1)
  zc=1.444-0.014*t
  radius=np.interp(xi,[.18,.23,.36,.45,.54,.62,.68],[.107,.116,.092,.069,.055,.050,.045])
  region=3 if xi<.57 else 4
  for j in range(152):
   a=2*math.pi*j/152
   z=zc+radius*math.cos(a)
   y=radius*.97*math.sin(a)
   add(x,y,z,region)
# Asymmetric front fur/skin patch: raised surface, colored from front right edge only.
for yy in range(520,856,4):
 z=(ybottom-yy)/pix
 for j in range(30):
  x=.116+j*.0048
  px=int(round(x0+x*pix))
  if not mask[yy,px]:continue
  # low-confidence brown hanging fur, with soft Y offset from main tunic surface
  y=-.205-.045*math.sin(j/29*math.pi)
  add(x,y,z,9)
points=np.asarray(P,dtype=np.float32)
colors=np.asarray(C,dtype=np.uint8)
tags=np.asarray(T,dtype=np.uint8)
parts=np.asarray(K,dtype=np.uint8)
assert len(points)>120000 and len(points)==len(tags)==len(colors)==len(parts)
outtype=np.dtype([("x","<f4"),("y","<f4"),("z","<f4"),("red","u1"),("green","u1"),("blue","u1"),("source","u1"),("confidence","u1"),("region","u1")])
allp=np.empty(len(points),dtype=outtype)
for i,k in enumerate(("x","y","z")):allp[k]=points[:,i]
for i,k in enumerate(("red","green","blue")):allp[k]=colors[:,i]
allp["source"],allp["confidence"]=tags[:,0],tags[:,1]
allp["region"]=parts
outfile=ROOT/"Kiviaja_mees_stage2B_v3_rounded_anatomy.ply"
with outfile.open("wb") as fp:
 fp.write(("ply\nformat binary_little_endian 1.0\n"
 "comment ModelFactory Stage 2B v3 - anatomically round point cloud PRIOR, NOT measured multiview\n"
 "comment no faces; no certified mesh; no rig\n"
 "element vertex "+str(len(points))+"\n"
 "property float x\nproperty float y\nproperty float z\nproperty uchar red\nproperty uchar green\nproperty uchar blue\n"
 "property uchar source\nproperty uchar confidence\nproperty uchar region\nend_header\n").encode("ascii"))
 allp.tofile(fp)
# Project from new points using z-buffer painter (point splats).
def render(angle,w=1024,h=1370,regions=False):
 a=math.radians(angle);c=math.cos(a);s=math.sin(a)
 horiz=points[:,0]*c+points[:,1]*s
 depth=-points[:,1]*c+points[:,0]*s
 u=np.rint(w/2+horiz*pix*.98).astype(np.int32)
 v=np.rint(h-78-points[:,2]*pix*.98).astype(np.int32)
 ok=(u>=2)&(u<w-2)&(v>=2)&(v<h-2)
 inds=np.flatnonzero(ok);inds=inds[np.argsort(depth[ok],kind="stable")]
 pic=Image.new("RGB",(w,h),(211,213,213));drawer=ImageDraw.Draw(pic)
 palette=np.asarray([[214,168,104],[191,189,121],[124,173,229],[188,139,206],[219,150,140],
 [187,170,111],[124,188,144],[110,157,196],[179,134,77],[157,110,73]],dtype=np.uint8)
 cols=palette[parts] if regions else colors
 for q in inds:
  uu=int(u[q]);vv=int(v[q]);cc=tuple(int(x) for x in cols[q])
  drawer.rectangle((uu-1,vv-1,uu+1,vv+1),fill=cc)
 return pic
for name,deg in [("FRONT",0),("LEFT",-90),("BACK",180),("RIGHT",90),("3Q",39)]:
 render(deg).save(ROOT/("Stage2B_v3_"+name+".png"))
render(0,regions=True).save(ROOT/"Stage2B_v3_regions.png")
tw,th=672,900
sht=Image.new("RGB",(2*tw,2*th+96),(228,228,228));d=ImageDraw.Draw(sht)
try:fnt=ImageFont.truetype("C:/Windows/Fonts/segoeuib.ttf",30)
except:fnt=ImageFont.load_default()
for i,name in enumerate(("FRONT","LEFT","BACK","RIGHT")):
 im=Image.open(ROOT/("Stage2B_v3_"+name+".png")).convert("RGB").resize((tw,th),Image.Resampling.LANCZOS)
 ox=i%2*tw;oy=(i//2)*th+48
 sht.paste(im,(ox,oy));d.rectangle((ox,oy-48,ox+tw,oy),fill=(42,46,48))
 d.text((ox+22,oy-42),name+" | 2B v3",font=fnt,fill="white")
sht.save(ROOT/"Stage2B_v3_FOUR_VIEWS.jpg",quality=89,optimize=True)
ang=Image.open(ROOT/"Stage2B_v3_3Q.png").convert("RGB")
ang.save(ROOT/"Stage2B_v3_ANGLE.jpg",quality=91,optimize=True)
state={"stage":"2B","iteration":"v3 rounded per-bodypart anatomy prior","status":"RESULT_REVIEW_NEEDED",
"points":len(points),"body_part_counts":{str(i):int((parts==i).sum())for i in range(10)},
"input_images":["Tpose_front.png","Tpose_back.png"],"unreliable_side_views_excluded":True,
"front_reconstruction":"approximate fit to image silhouette","back_reconstruction":"image color not calibrated",
"geometry_true_from_multiview":False,"point_cloud_only":True,"mesh_created":False,"rig_created":False,
"output_ply":outfile.name,"sha256":hashlib.sha256(outfile.read_bytes()).hexdigest(),
"preview_sheet":"Stage2B_v3_FOUR_VIEWS.jpg","preview_angle":"Stage2B_v3_ANGLE.jpg",
"next":"2C after user's explicit permission"}
(ROOT/"Stage2B_v3_manifest.json").write_text(json.dumps(state,indent=2,ensure_ascii=False),encoding="utf8")
print("V3_ROUNDED_DONE",json.dumps({"points":len(points),"sha256":state["sha256"],"ply_bytes":outfile.stat().st_size}),flush=True)

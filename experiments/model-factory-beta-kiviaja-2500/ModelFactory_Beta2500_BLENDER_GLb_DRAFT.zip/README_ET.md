# ModelFactory Beta 0.1.6 — kiviaja inimene 2500 (katse 2026-10-27)

STAATUS: NEEDS_REPAIR / EI OLE VALMIS ega heaks kiidetud retsept.
Kasutaja taotlus: "ModelFactory Beta 2500 kiviaja inimene"; eelmist 3000-quad prototüüpi ei taaskasutatud.

## Tegelik väljund
- 2433 QUAD-tahku kogu tegelasel; siht- ja ülempiir 2500
- 4866 GLB-ekspordi kolmnurka, kontrollitud GLB taassisestamisel
- 1808 quadi kehal, ülejäänud riietele, juustele ja aksessuaaridele
- Stabiilsed Blenderi .blend, GLB ja OBJ failid ning viis tõelist Blenderi kontrollvaadet
- Kõik osad ei ole ühendatud üheks deformeeritavaks võrguks

## Mis sai sisuliselt tehtud
Objektipõhine inimese algretsept loodud Beta recipe_library.py init käsuga: family=human, subject=kiviaja inimene, quads=2500, level=2.
Anatoomiline lähtekuju: MakeHumani CC0 basemesh ja male target, Blender 4.5.15.
Punktipilv source_prior_cloud_v3.npz koos ette kirjutatud kolme telje projektsioonidega.
OLULINE: see punktipilv on tuletatud litsentseeritud SOURCE-ALUSVÕRGUST, MITTE sõltumatult kalibreeritud AI mitmikvaadetest. Kõik 13380 punkti on sügavuselt oletuslikud; sõltumatult kinnitatud osakaal on 0%. Seetõttu Beta 3-vaate kvaliteedigate EI LÄBI.
Valmis kolmnurkeksport on prototüüp, mitte piltide rekonstruktsioon.

## Kontrollitud probleemid
1. Randmed ja sõrmed venivad ning deformeeruvad T-poosiks muutmisel.
2. Globaalne QuadriFlow kaotab nina, silmade, kõrvade ning lõualuu anatoomilised detailid.
3. Rõivaste ülemine osa ja karusnahk on nõrga siluetiga; mõned osad mõjuvad kõvadena.
4. Juukse- ja habemekaardid ei vasta lõpliku detailitaseme kvaliteedile.
5. Puudub sõltumatu kolme kaamerasuuna reaalne kujutise-punkti vastavuskontroll.
6. Puuduvad rig, korrektsed deformatsioonikaalud, tekstuuri UV bake, deformatsioonitestid ja lõplik orgaanilise kvaliteedi gate.
7. check_acceptance.py --organic --quad-budget 2500 tagastas 'needs_repair'.

## Õige parandustee
Rakenda käelabadele päris luustik ja nahastus enne poosi pööramist.
Tee inimpea/fingerite eraldi anatoomiat säilitav topoloogia ning liida deformeeritavad ühendused puhtalt.
Kinnita tegelikud mõõdistatud ees/külg/ülalt pildid ja nende punktivastavused; eemalda source-only prior teadmatus.
Alles pärast kuju heakskiitu tööta välja pehmem rõivastus, PBR tekstuurid, animatsioon ja eksport.
Ära registreeri seda retsepti Beta valideeritud kogusse enne heakskiitu.

## Failid
- output/StoneAgeHuman2500_Beta_DRAFT.glb
- output/StoneAgeHuman2500_Beta_EDIT.blend
- output/StoneAgeHuman2500_Beta_quads.obj
- output/front.png, oblique.png, back.png, left.png, right.png, top.png
- output/mesh_audit.json, output/quality-gate.json
- cloud/source_prior_cloud_v3.npz, cloud/prior_calibration.json
- references/source_prior_Tpose_v3.blend
- request.json, recipe-draft.json
- root generator scripts

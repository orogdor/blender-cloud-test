# ModelFactory Lab — Kiviaja inimene, päris uus algus (27.10.2026)

## Seis: NEEDS_REPAIR — see EI OLE valmis 3000-quad mängumudel

Eelmise katse `kiviaja_3000_v1` ja `v2` mudelit ega katki remeshed anatoomiat ei kasutatud.
Päris uus neutraalne inimkeha tehti MakeHumani CC0 `base.obj` failist ja `caucasian-male-young.target` morfist.
Lisaks segati 18% max-muscle sihtkuju. Blender 4.5.15 lokaalne käivitus kontrolliti.

## Mis päriselt töötab

- Uus mehe anatoomiline keha, korrektse nina/kõrvade/huulte/jäsemete alusgeomeetriaga.
- 13 378 lähtemudeli quadi, 13 380 vertexit; kõrgus normaliseeriti 1,78 meetrini.
- `01-references/male_anatomy_master.blend` — uus redigeeritav anatoomiline alus.
- `03-mesh/MakeHuman_CC0_male_clean_baseline.glb` — uus GLB edukalt eksporditud ja imporditud (26 756 kolmnurka).
- 4+ vaadet päriselt kohalikus Blenderis renderdatud.
- Kohalik Qwen 3.5 9B koostas tehnilised ettepanekud `qwen_anatomy_recipe.json` (soovitused, mitte tõestatud kvaliteet).
- ModelFactory Lab ühises retseptikataloogis ei ole kinnitatud 3000-quadi inimese retsepti; vanad kaks 1000-quadi retsepti on `needs_repair`.

## Mis nurjus, mida mitte esitleda valmismudelina

- Riide/juukse proov (REPAIR2) on 17 048 kõrge detailsusega tahku, mitte 3000.
- Käte T-poosi muutmise meetod rikub randmed/käelabad. Selleks tuleb kasutada sobivat armatuuri ja korralikult kaalutud skeleti deformatsiooni.
- Juuksed on hõredad ja kujundatud liiga sirgete ribadena, mitte kontrollitud juuksekaartide süsteemina.
- Rõivastuse siluett, õlapelt ning vöökohas olevad lõiked ei vasta heakskiidetavale mängutasemele.
- Puuduvad päris UV/PBR tekstuuride bake, korrektne rig/animatsioon, pea detailide kujuülevaatus, 3000-quad quad-mesh ja sõltumatu kvaliteedikontroll.
- Pilti `04-preview/Kiviaja_uus_alustamine_AUDIT.jpg` vaadata võrdluse, mitte heakskiidetud mudelina.

## Õige järgmine tehniline samm

Kasuta uut 13 378 quad keha alusena, mitte varasemat läbikukkunud 3000 quadi mudelit.
Ehita korralik skelett ning tee MakeHumani A-poosist T-poos käsivarre- ja randmeluude ning kaaludega.
Alles seejärel tee rõivaste lõiked ja juuksekaardid anatoomia pinnale ning kinnita nende kvaliteet.
Lõpuks bake UV/PBR tekstuurid ja tee näopiirkondi säilitav 3000 quad retopoloogia.
Igas etapis vaata enne edasiminekut eest, mõlemalt küljelt, tagant, pealt ja 3/4 renderit.

Litsents: MakeHuman baasmudeli ja sihtkujude allikas https://github.com/makehumancommunity/makehuman (CC0, info nende failide päistes).
